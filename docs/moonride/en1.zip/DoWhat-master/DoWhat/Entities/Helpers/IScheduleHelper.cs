﻿using System.Collections.Generic;

namespace Entities.Helpers
{
    /// <summary>
    /// 表示一个时间安排帮助器。
    /// </summary>
    public interface IScheduleHelper
    {
        /// <summary>
        /// 绑定到数据帮助器。
        /// </summary>
        /// <param name="data">要绑定的帮助器。</param>
        void SetData(IDataHelper data);

        /// <summary>
        /// 计算生成时间安排表。
        /// </summary>
        IEnumerable<TodoRelated.ITodoInSchedule> ProduceSchedules();
    }
}
