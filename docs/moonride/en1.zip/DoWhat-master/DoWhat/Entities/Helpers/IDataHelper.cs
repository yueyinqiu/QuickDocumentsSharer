﻿using Entities.TodoRelated;
using System;
using System.Collections.Generic;

namespace Entities.Helpers
{
    /// <summary>
    /// 表示一个数据帮助器。
    /// </summary>
    public interface IDataHelper : IDisposable
    {
        /// <summary>
        /// 储存一个新的普通事务。
        /// </summary>
        /// <param name="info">事务信息。</param>
        /// <returns>储存结果。</returns>
        ICommonTodo CreateNew(ICommonTodoInfo info);
        /// <summary>
        /// 储存一个新的循环事务。
        /// </summary>
        /// <param name="info">事务信息。</param>
        /// <returns>储存结果。</returns>
        ILoopTodo CreateNew(ILoopTodoInfo info);
        /// <summary>
        /// 储存一个新的事务类别。
        /// </summary>
        /// <param name="info">类别信息。</param>
        /// <returns>储存结果。</returns>
        ITodoCategory CreateNew(ITodoCategoryInfo info);

        /// <summary>
        /// 移除一个事务。
        /// </summary>
        /// <param name="todo">事务。</param>
        /// <returns></returns>
        bool Remove(ITodo todo);
        /// <summary>
        /// 移除一个事务类别。
        /// </summary>
        /// <param name="category">事务类别。</param>
        /// <returns></returns>
        bool Remove(ITodoCategory category);
        /// <summary>
        /// 修改一个事务的信息。
        /// </summary>
        /// <param name="todo">事务。</param>
        /// <param name="info">信息。</param>
        /// <returns></returns>
        bool Change(ITodo todo, ICommonTodoInfo info);
        /// <summary>
        /// 修改一个事务的信息。
        /// </summary>
        /// <param name="todo">事务。</param>
        /// <param name="info">信息。</param>
        /// <returns></returns>
        bool Change(ITodo todo, ILoopTodoInfo info);

        /// <summary>
        /// 获取所保存的事务安排表。
        /// </summary>
        /// <returns></returns>
        IEnumerable<ITodoInSchedule> GetSavedArrangement();

        /// <summary>
        /// 保存事务安排表。
        /// </summary>
        void SaveArrangement(IEnumerable<ITodoInSchedule> arrangement);

        /// <summary>
        /// 转换到循环事务。
        /// </summary>
        /// <param name="todo">事务。</param>
        /// <returns></returns>
        ILoopTodo GetLoopTodo(ITodo todo);
        /// <summary>
        /// 转换到普通事务。
        /// </summary>
        /// <param name="todo">事务。</param>
        /// <returns></returns>
        ICommonTodo GetCommonTodo(ITodo todo);
        /// <summary>
        /// 获取一个事务类别。
        /// </summary>
        /// <param name="todo">类别标识号。</param>
        /// <returns></returns>
        ITodoCategory GetCategory(int categoryId);
        /// <summary>
        /// 获取所有普通事务。
        /// </summary>
        IEnumerable<ICommonTodo> AllCommonTodos { get; }
        /// <summary>
        /// 获取所有循环事务。
        /// </summary>
        IEnumerable<ILoopTodo> AllLoopTodos { get; }
    }
}
