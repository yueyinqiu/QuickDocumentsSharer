﻿using System;

namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示一个在日程表中的事务。日程表应由一系列的该接口实现构成。
    /// </summary>
    public interface ITodoInSchedule
    {
        /// <summary>
        /// 该次的开始时间。
        /// </summary>
        DateTime StartTime { get; }
        /// <summary>
        /// 该次的开始时间。
        /// </summary>
        DateTime EndTime { get; }
        /// <summary>
        /// 指示事务。
        /// </summary>
        ITodo Todo { get; }
        /// <summary>
        /// 该次的完成度。
        /// </summary>
        CompletionPercentRange CompletionPercent { get; }
    }
}
