﻿namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示循环事务的循环模式。
    /// </summary>
    public enum LoopMode
    {
        /// <summary>
        /// 表示按一枚举类型进行。
        /// </summary>
        ByEnumerable,
        /// <summary>
        /// 表示按星期进行。
        /// </summary>
        SomeDaysOfWeek
    }
}