﻿namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示完成度。
    /// </summary>
    public class CompletionPercentRange
    {
        /// <summary>
        /// 从此处开始（百分之）。
        /// </summary>
        public int From { get; }
        /// <summary>
        /// 至此处结束（百分之）。
        /// </summary>
        public int To { get; }
        /// <summary>
        /// 完成量（百分之）。
        /// </summary>
        public int Difference { get; }
        /// <summary>
        /// 创建一个完成度。
        /// </summary>
        /// <param name="from">从此处开始（百分之）。</param>
        /// <param name="to">至此处结束（百分之）。</param>
        public CompletionPercentRange(int from, int to)
        {
            this.From = from;
            this.To = to;
            this.Difference = to - from;
        }
    }
}
