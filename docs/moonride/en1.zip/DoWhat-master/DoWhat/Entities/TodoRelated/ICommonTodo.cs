﻿using System;

namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示一个普通事务的信息。
    /// </summary>
    public interface ICommonTodoInfo
    {
        /// <summary>
        /// 获取事务的类型。
        /// </summary>
        int CategoryId { get; }
        /// <summary>
        /// 获取事务的名称。
        /// </summary>
        string Title { get; }

        /// <summary>
        /// 获取事务的最早开始时间。
        /// </summary>
        DateTime EarliestStartTime { get; }

        /// <summary>
        /// 获取事务的截止日期。
        /// </summary>
        DateTime Deadline { get; }

        /// <summary>
        /// 获取进行该事务需要消耗的时间。
        /// </summary>
        TimeSpan Consumption { get; }

        /// <summary>
        /// 获取该事务的重要性。
        /// 此值多以表达式 <see cref="Importance"/> / 100 计算得到的值代入公式计算。
        /// 数字越大，表示其越重要。
        /// </summary>
        int Importance { get; }
    }
    /// <summary>
    /// 表示一个普通事务。
    /// </summary>
    public interface ICommonTodo : ITodo
    {
        /// <summary>
        /// 获取事务的信息。
        /// </summary>
        ICommonTodoInfo Info { get; }
    }
}
