﻿using System;

namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示按星期循环的事务的循环方式。
    /// </summary>
    public interface IDayOfWeekLoopInfo
    {
        /// <summary>
        /// 触发的星期。
        /// </summary>
        DayOfWeekFlags Days { get; }

        /// <summary>
        /// 此属性中超过一天的部分会被忽略。
        /// </summary>
        TimeSpan Time { get; }
    }
}
