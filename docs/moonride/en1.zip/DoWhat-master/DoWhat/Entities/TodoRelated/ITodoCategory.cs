﻿namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示一个事务类型的信息。
    /// </summary>
    public interface ITodoCategoryInfo
    {
        /// <summary>
        /// 获取事务类型的描述。
        /// </summary>
        string Title { get; }
    }
    /// <summary>
    /// 表示一个事务类型。
    /// </summary>
    public interface ITodoCategory
    {
        /// <summary>
        /// 获取事务类型的标识号。注意判断是否是同个事务类型时，应判断本标识号。
        /// </summary>
        int Id { get; }

        /// <summary>
        /// 获取事务类型的信息。
        /// </summary>
        ITodoCategoryInfo Info { get; }
    }
}
