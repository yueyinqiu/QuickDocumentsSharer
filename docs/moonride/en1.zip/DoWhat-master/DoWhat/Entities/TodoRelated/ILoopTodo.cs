﻿using System;
using System.Collections.Generic;

namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示一个循环事务的信息。
    /// </summary>
    public interface ILoopTodoInfo
    {
        /// <summary>
        /// 事务的描述。
        /// </summary>
        string Title { get; }
        /// <summary>
        /// 循环模式。
        /// </summary>
        LoopMode Mode { get; }

        /// <summary>
        /// 确认具体循环方式所需要的信息。
        /// 该值的具体类型与 <see cref="Mode"/> 属性有关。
        /// 如果其值为 <see cref="LoopMode.ByEnumerable"/> 此处类型应为 <see cref="IEnumerable{DateTime}"/> ， 必须是从小到大有序的。
        /// 如果其值为 <see cref="LoopMode.SomeDaysOfWeek"/> 此处类型应为 <see cref="IDayOfWeekLoopInfo"/>。
        /// </summary>
        dynamic LoopInfo { get; }

        /// <summary>
        /// 开始时间。
        /// </summary>
        DateTime StartTime { get; }

        /// <summary>
        /// 结束时间。
        /// </summary>
        DateTime EndTime { get; }

        /// <summary>
        /// 完成一次事务需要的时间。
        /// </summary>
        TimeSpan Consumption { get; }
    }
    /// <summary>
    /// 表示一个循环事务。
    /// </summary>
    public interface ILoopTodo : ITodo
    {
        /// <summary>
        /// 获取事务的信息。
        /// </summary>
        ILoopTodoInfo Info { get; }
    }
}
