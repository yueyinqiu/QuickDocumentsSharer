﻿namespace Entities.TodoRelated
{
    /// <summary>
    /// 表示一个事务。
    /// </summary>
    public interface ITodo
    {
        /// <summary>
        /// 事务的标识号。
        /// </summary>
        int Id { get; }
    }
}