﻿using Entities.Helpers;

namespace ScheduleHelpers
{
    public class Factory
    {
        public static IScheduleHelper GetScheduleHelper()
            => new Standard.ScheduleHelper();
    }
}
