﻿using Entities.Helpers;
using Entities.TodoRelated;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScheduleHelpers.Standard
{
    public class ScheduleHelper : IScheduleHelper
    {
        private IDataHelper data;

        public void SetData(IDataHelper data)
        {
            this.data = data;
        }
        public IEnumerable<ITodoInSchedule> ProduceSchedules()
        {
            TimeConverter timeConverter = new TimeConverter {
                LoopTodos = this.data.AllLoopTodos,
            };

            var contractedTodos = this.Contract(timeConverter, this.data.AllCommonTodos);
            var contractedTodosArray = contractedTodos.ToArray();
            var permutations = new TodoPermutations(contractedTodosArray,
                DateTime.Now - timeConverter.ZeroTime + new TimeSpan(0, 5, 0));

            var bestOrder = this.GetBestOrder(contractedTodosArray.Length, permutations);

            return this.RestoreTodos(bestOrder, timeConverter);
        }
        private LinkedList<TodoInSchedule> RestoreTodos(
            TodoInLine[] commonTodosOrder, TimeConverter timeConverter)
        {
            var result = new LinkedList<TodoInSchedule>();
            foreach (var commonTodo in commonTodosOrder)
            {
                var todoInSchedule = new TodoInSchedule {
                    Todo = commonTodo.Todo,
                    CompletionPercent = new CompletionPercentRange(0, 100),

                    StartTime = timeConverter.RestoreTime(commonTodo.StartTime),
                    EndTime = timeConverter.RestoreTime(commonTodo.EndTime)
                };
                result.AddLast(todoInSchedule);
            }
#warning TODO: 分割result中已存有的事务，并将固定事务插入表中。
            // throw new NotImplementedException();
            return result;
        }

        private IEnumerable<TodoInLine[]> GetTheBestOrders(IEnumerable<TodoInLine[]> competitors, int splitPlace)
        {
            double bestScore = 0D;
            List<TodoInLine[]> bestOnes = new List<TodoInLine[]>();
            foreach (var currentPermutation in competitors)
            {
                var score = this.ScoreOf(currentPermutation, splitPlace);
                if (score > bestScore)
                {
                    bestOnes = new List<TodoInLine[]> {
                            currentPermutation
                        };
                    bestScore = score;
                }
                else if (score == bestScore)
                {
                    bestOnes.Add(currentPermutation);
                }
            }
            return bestOnes;
        }

        private TodoInLine[] GetBestOrder(int eachLength, TodoPermutations permutations)
        {
            var allPermutations = permutations.ToEnumerable();
            IEnumerable<TodoInLine[]> bestOnes = this.GetTheBestOrders(allPermutations, eachLength / 2);
            int[] splitPlaces = new int[]
            {
                eachLength * 3 / 8,
                eachLength * 5 / 8,
                eachLength / 4,
                eachLength * 3 / 4,
                eachLength / 8,
                eachLength * 7 / 8
            };

            for (int comparedTimes = 0;
                bestOnes.CountIsMoreThan(1) && comparedTimes < splitPlaces.Length;
                comparedTimes++)
            {
                bestOnes = this.GetTheBestOrders(bestOnes, splitPlaces[comparedTimes]);
            }

            return bestOnes.First();
        }
        private double ScoreOfHalf(TodoInLine[] todos)
        {
            CategoryCounter counter = new CategoryCounter();
            foreach (var todo in todos)
            {
                counter.Count(todo.Category);
            }
            var countResult = counter.Result;
            double result = 1D;
            double allTodosCount = todos.Length;
            foreach (var (_, count) in countResult)
            {
                double countDivideByAll = count / allTodosCount;
                result -= countDivideByAll * countDivideByAll;
            }
            return result;
        }
        private double ScoreOf(TodoInLine[] todos, int splitAfter)
        {
            int splitAfterAddOne = splitAfter + 1;
            TodoInLine[] before = new TodoInLine[splitAfterAddOne];
            for (int i = 0; i < before.Length; i++)
            {
                before[i] = todos[i];
            }
            TodoInLine[] after = new TodoInLine[todos.Length - splitAfterAddOne];
            for (int i = 0; i < after.Length; i++)
            {
                after[i] = todos[i + splitAfter];
            }

            return this.ScoreOfHalf(before) + this.ScoreOfHalf(after);
        }
        private List<ContractedTodo> Contract(TimeConverter timeConverter,
            IEnumerable<ICommonTodo> commonTodos)
        {
            var result = new List<ContractedTodo>();
            DateTime nowAdd5 = DateTime.Now.AddMinutes(5);
            TimeSpan compressedNowAdd5 = timeConverter.CompressTime(nowAdd5);
            foreach (var todo in commonTodos)
            {
                ContractedTodo contractedTodo = new ContractedTodo() { Todo = todo };
                result.Add(contractedTodo);
                var originInfo = todo.Info;

                contractedTodo.Category = originInfo.CategoryId;


                TimeSpan earliestTimeTemp;
                if (originInfo.EarliestStartTime <= nowAdd5)
                {
                    earliestTimeTemp = compressedNowAdd5;
                }
                else
                {
                    earliestTimeTemp =
                        timeConverter.CompressTime(originInfo.EarliestStartTime);
                }
                contractedTodo.EarliestTime = earliestTimeTemp;


                contractedTodo.Consumption = new TimeSpan(
                    originInfo.Consumption.Ticks +
                    (long)(ImportanceInfluences.OnConsumption *
                    originInfo.Consumption.Ticks * originInfo.Importance / 100));


                var deadlineTemp = timeConverter.CompressTime(originInfo.Deadline);
                contractedTodo.Deadline = new TimeSpan(
                    deadlineTemp.Ticks -
                    (long)(ImportanceInfluences.OnDeadline *
                    (deadlineTemp.Ticks - earliestTimeTemp.Ticks) * originInfo.Importance / 100));
            }
            return result;
        }
    }
}