﻿using System;
using System.Collections.Generic;

namespace ScheduleHelpers.Standard
{
    internal class TodoPermutations
    {
        private readonly ContractedTodo[] allItems;
        private readonly TimeSpan startTime;
        public TodoPermutations(ContractedTodo[] allItems, TimeSpan startTime)
        {
            this.allItems = allItems;
            this.startTime = startTime;
        }
        public IEnumerable<TodoInLine[]> ToEnumerable()
        {
            int[] indexs = new int[this.allItems.Length];
            /*
            for (int i = 0; i < index.Length; i++)
            {
                index[i] = 0;
            }
            */
            indexs[indexs.Length - 1] = -1;
            bool addPosition()
            {
                for (int position = indexs.Length - 1; ;)
                {
                    indexs[position]++;
                    if (indexs[position] >= this.allItems.Length)
                    {
                        if (position == 0)
                        {
                            return false;
                        }
                        indexs[position] = 0;
                        position--;
                        continue;
                    }
                    break;
                }
                return true;
            }
            for (; addPosition();)
            {
                TimeSpan now = this.startTime;
                bool canUse = true;
                TodoInLine[] result = new TodoInLine[this.allItems.Length];
                int i = 0;
                foreach (var index in indexs)
                {
                    // 查重复
                    {
                        int repeatCount = 0;
                        foreach (var index2 in indexs)
                        {
                            if (index == index2)
                            {
                                repeatCount++;
                                if (repeatCount >= 2)
                                {
                                    canUse = false;
                                    break;
                                }
                            }
                        }
                        if (!canUse)
                        {
                            break;
                        }
                    }
                    // 查时间
                    var todo = this.allItems[index];
                    result[i] = new TodoInLine() {
                        Category = todo.Category,
                        Todo = todo.Todo
                    };
                    if (todo.EarliestTime > now)
                    {
                        now = todo.EarliestTime;
                    }
                    result[i].StartTime = now;
                    now += todo.Consumption;
                    if (todo.Deadline < now)
                    {
                        canUse = false;
                        break;
                    }
                    result[i].EndTime = now;
                    i++;
                }
                if (canUse)
                {
                    yield return result;
                }
            }
            yield break;
        }
    }
}
