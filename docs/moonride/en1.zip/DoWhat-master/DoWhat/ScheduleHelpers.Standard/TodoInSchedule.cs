﻿using Entities.TodoRelated;
using System;

namespace ScheduleHelpers.Standard
{
    internal class TodoInSchedule : Entities.TodoRelated.ITodoInSchedule
    {
        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        public ITodo Todo { get; set; }

        public CompletionPercentRange CompletionPercent { get; set; }
    }
}
