﻿using System.Collections.Generic;

namespace ScheduleHelpers.Standard
{
    internal static class IEnumerableExtensions
    {
        public static bool CountIsMoreThan<T>(this IEnumerable<T> enumerable, int count)
        {
            int counter = 0;
            foreach (var item in enumerable)
            {
                counter++;
                if (counter > count)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
