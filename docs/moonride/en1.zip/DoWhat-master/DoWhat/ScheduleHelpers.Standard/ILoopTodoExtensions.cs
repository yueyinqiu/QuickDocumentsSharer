﻿using Entities.TodoRelated;
using System;

namespace ScheduleHelpers.Standard
{
    internal static class ILoopTodoExtensions
    {
        private static readonly TimeSpan OneFullDay = new TimeSpan(1, 0, 0, 0);
        private static TimeSpan GetTimeTakenInByEnumerable(ILoopTodoInfo todoInfo, DateTime after, DateTime before)
        {
            var consumption = todoInfo.Consumption;
            var start = todoInfo.StartTime;
            if (start < after)
            {
                start = after;
            }
            var end = todoInfo.EndTime;
            if (before < end)
            {
                end = before;
            }

            TimeSpan result = TimeSpan.Zero;
            foreach (DateTime time in todoInfo.LoopInfo)
            {
                if (time > start)
                {
                    if (time < end)
                    {
                        if (time + consumption < end)
                            result += consumption;
                        else
                        {
                            result += end - time;
                            break;
                        }
                    }
                    else
                        break;
                }
                else if (time + consumption > start)
                    result += consumption - (start - time);
            }
            return result;
        }
        private static TimeSpan GetTimeTakenInSomeDaysOfWeek(ILoopTodoInfo todoInfo, DateTime after, DateTime before)
        {
            var consumption = todoInfo.Consumption;
            var end = todoInfo.EndTime;
            if (before < end)
            {
                end = before;
            }
            IDayOfWeekLoopInfo loopInfo = todoInfo.LoopInfo;
            var days = loopInfo.Days;
            var time = loopInfo.Time;

            TimeSpan result = TimeSpan.Zero;
            var start = todoInfo.StartTime;
            if (start < after)
            {
                start = after;
            }

            var sdc = start - consumption;
            if (sdc.Day == start.Day)
            {
                if (days.HasFlag(sdc.DayOfWeek.ToFlagsType())
                    && sdc.TimeOfDay < time)
                {
                    start = new DateTime(start.Year, start.Month, start.Day,
                        time.Hours, time.Minutes, time.Seconds, time.Milliseconds);
                    if (start + consumption <= end)
                    {
                        result += consumption;
                    }
                    else
                    {
                        result += end - start;
                    }
                }
                start = new DateTime(start.Year, start.Month, start.Day + 1,
                    time.Hours, time.Minutes, time.Seconds, time.Milliseconds);
            }
            else
            {
                if (days.HasFlag(sdc.DayOfWeek.ToFlagsType())
                    && sdc.TimeOfDay < time)
                {
                    var tempDateTime = new DateTime(sdc.Year, sdc.Month, sdc.Day,
                        time.Hours, time.Minutes, time.Seconds, time.Milliseconds);
                    if (tempDateTime + consumption <= end)
                    {
                        result += consumption;
                    }
                    else
                    {
                        result += end - tempDateTime;
                    }
                }
                start = new DateTime(start.Year, start.Month, start.Day,
                    time.Hours, time.Minutes, time.Seconds, time.Milliseconds);
            }




            for (; start + consumption < end; start += OneFullDay)
            {
                if (days.HasFlag(start.DayOfWeek.ToFlagsType()))
                {
                    result += consumption;
                }
            }
            if (start < end)
                result += end - start;
            return result;
        }
        public static TimeSpan GetTimeTakenIn(this ILoopTodo loopTodo, DateTime after, DateTime before)
        {
            var todoInfo = loopTodo.Info;
            switch (todoInfo.Mode)
            {
                case LoopMode.ByEnumerable:
                    return GetTimeTakenInByEnumerable(todoInfo, after, before);
                case LoopMode.SomeDaysOfWeek:
                    return GetTimeTakenInSomeDaysOfWeek(todoInfo, after, before);
                default:
                    throw new ArgumentException(nameof(loopTodo));
            }
        }
    }
}
