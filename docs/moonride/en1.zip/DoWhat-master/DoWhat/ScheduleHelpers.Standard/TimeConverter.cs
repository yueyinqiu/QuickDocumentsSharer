﻿using Entities.TodoRelated;
using System;
using System.Collections.Generic;

namespace ScheduleHelpers.Standard
{
    internal class TimeConverter
    {
        private IEnumerable<ILoopTodo> loopTodos = new ILoopTodo[0];
        public IEnumerable<ILoopTodo> LoopTodos
        {
            get => this.loopTodos;
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(value));
                }
                this.loopTodos = value;
            }
        }

        public DateTime ZeroTime { get; set; } = DateTime.MinValue;

        public DateTime RestoreTime(TimeSpan compressedTime)
        {
            var result = this.ZeroTime + compressedTime;
            for (bool stop = true; !stop; stop = true)
            {
                foreach (var loopTodo in this.LoopTodos)
                {
                    var time = loopTodo.GetTimeTakenIn(DateTime.MinValue, result); ;
                    if (time != TimeSpan.Zero)
                    {
                        result += time;
                        stop = false;
                    }
                }
            }
            return result;
        }

        public TimeSpan CompressTime(DateTime time)
        {
            var result = time - this.ZeroTime;
            foreach (var loopTodo in this.LoopTodos)
            {
                result -= loopTodo.GetTimeTakenIn(DateTime.MinValue, time);
            }
            return result;
        }
    }
}
