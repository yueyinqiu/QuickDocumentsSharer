﻿using Entities.TodoRelated;
using System;

namespace ScheduleHelpers.Standard
{
    internal class TodoInLine
    {
        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        public int Category { get; set; }

        public ITodo Todo { get; set; }
    }
}
