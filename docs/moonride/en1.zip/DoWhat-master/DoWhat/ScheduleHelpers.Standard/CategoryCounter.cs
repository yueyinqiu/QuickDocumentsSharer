﻿using System.Collections.Generic;
using System.Linq;

namespace ScheduleHelpers.Standard
{
    internal class CategoryCounter
    {
        private readonly Dictionary<int, int> CategoryIdAndCountPairs =
            new Dictionary<int, int>();
        public void Count(int categoryId)
        {
            if (this.CategoryIdAndCountPairs.ContainsKey(categoryId))
            {
                this.CategoryIdAndCountPairs[categoryId]++;
            }
            else
            {
                this.CategoryIdAndCountPairs.Add(categoryId, 1);
            }
        }

        public IEnumerable<(int category, int count)> Result
        {
            get
            {
                return
                    from idToCat in this.CategoryIdAndCountPairs
                    select (idToCat.Key, idToCat.Value);
            }
        }
    }
}
