﻿namespace ScheduleHelpers.Standard
{
    internal static class ImportanceInfluences
    {
        public static double OnDeadline { get; } = 0.1;
        public static double OnConsumption { get; } = 0.32;
    }
}
