﻿using Entities.TodoRelated;
using System;

namespace ScheduleHelpers.Standard
{
    internal class ContractedTodo
    {
        public ITodo Todo { get; set; }

        public int Category { get; set; }

        public TimeSpan EarliestTime { get; set; }

        public TimeSpan Deadline { get; set; }

        public TimeSpan Consumption { get; set; }
    }
}
