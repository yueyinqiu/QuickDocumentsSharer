﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Text;

namespace DataHelpers.SQLite.Standard
{
    internal class DBHelper : IDisposable
    {
        private readonly SQLiteConnection connection;
        public DBHelper(string dbPath)
        {
            this.connection = new SQLiteConnection();
            this.connection.Open();
        }

        #region Transaction
        private SQLiteTransaction transaction = null;
        public void TransactionStart()
        {
            if (this.transaction == null)
                this.transaction = this.connection.BeginTransaction();
        }
        public void TransactionCommit()
        {
            if (this.transaction != null)
            {
                this.transaction.Commit();
                this.transaction.Dispose();
                this.transaction = null;
            }
        }
        public void TransactionRollBack()
        {
            if (this.transaction != null)
            {
                this.transaction.Dispose();
                this.transaction = null;
            }
        }
        #endregion

        public SQLiteDataReader ExecuteReader(string sql,
            params (string Name, object Value)[] parameters)
        {
            var command = this.connection.CreateCommand();

            foreach (var (name, value) in parameters)
            {
                var sqlParameter = command.CreateParameter();
                sqlParameter.ParameterName = name;
                sqlParameter.Value = value;
            }

            return command.ExecuteReader();
        }
        public void Execute()
        {

        }

        public void Dispose()
        {
            this.transaction?.Dispose();
            this.connection.Dispose();
        }
    }
}
