﻿using DataHelpers.SQLite;
using Entities.Helpers;
using Entities.TodoRelated;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHelpers.SQLite.Standard
{
    internal class SQLiteHelper : Entities.Helpers.IDataHelper
    {
        private DBHelper dataBase;
        public SQLiteHelper(string rootPath)
        {
            this.dataBase = new DBHelper(Path.Combine(rootPath, "main.db"));
        }

        public IEnumerable<ICommonTodo> AllCommonTodos => throw new NotImplementedException();

        public IEnumerable<ILoopTodo> AllLoopTodos => throw new NotImplementedException();

        public bool Change(ITodo todo, ICommonTodoInfo info) => throw new NotImplementedException();
        public bool Change(ITodo todo, ILoopTodoInfo info) => throw new NotImplementedException();
        public ICommonTodo CreateNew(ICommonTodoInfo info) => throw new NotImplementedException();
        public ILoopTodo CreateNew(ILoopTodoInfo info) => throw new NotImplementedException();
        public ITodoCategory CreateNew(ITodoCategoryInfo info) => throw new NotImplementedException();
        public void Dispose() => throw new NotImplementedException();
        public ITodoCategory GetCategory(int categoryId) => throw new NotImplementedException();
        public ICommonTodo GetCommonTodo(ITodo todo) => throw new NotImplementedException();
        public ILoopTodo GetLoopTodo(ITodo todo) => throw new NotImplementedException();
        public IEnumerable<ITodoInSchedule> GetSavedArrangement() => throw new NotImplementedException();
        public bool Remove(ITodo todo) => throw new NotImplementedException();
        public bool Remove(ITodoCategory category) => throw new NotImplementedException();
        public void SaveArrangement(IEnumerable<ITodoInSchedule> arrangement) => throw new NotImplementedException();
    }
}
