﻿using Entities.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHelpers
{
    public static class Factory
    {
        public static IDataHelper GetHelper(string rootPath)
        {
            return new SQLite.Standard.SQLiteHelper(rootPath);
        }
    }
}
