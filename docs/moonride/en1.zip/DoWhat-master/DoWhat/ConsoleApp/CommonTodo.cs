﻿using Entities.TodoRelated;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class CommonTodo : ICommonTodo
    {
        public ICommonTodoInfo Info { get; set; }

        public int Id { get; set; }
        public class CommonTodoInfo : ICommonTodoInfo
        {
            public int CategoryId { get; set; }

            public DateTime EarliestStartTime { get; set; }

            public DateTime Deadline { get; set; }

            public TimeSpan Consumption { get; set; }

            public int Importance { get; set; }

            public string Title { get; set; }
        }
    }
}
