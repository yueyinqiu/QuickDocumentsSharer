﻿using Entities.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Program
    {
        private static void Main()
        {
            IDataHelper data = DataHelpers.Memory.Standard.Factory.GetHelper();
            int[] cats = { 1, 2, 2, 3, 2, 2 };
            foreach (var cat in cats)
            {
                var task = new CommonTodo.CommonTodoInfo() {
                    CategoryId = cat,
                    Consumption = new TimeSpan(0, 10, 0),
                    Deadline = new DateTime(2020, 12, 1),
                    Importance = 100
                };
                data.CreateNew(task);
            }
            var helper = ScheduleHelpers.Factory.GetScheduleHelper();
            helper.SetData(data);
            helper.ProduceSchedules();
        }
    }
}
