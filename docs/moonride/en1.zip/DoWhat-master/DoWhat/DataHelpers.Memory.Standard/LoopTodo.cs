﻿using Entities.TodoRelated;

namespace DataHelpers.Memory.Standard
{
    internal class LoopTodo : ILoopTodo
    {
        public ILoopTodoInfo Info { get; set; }

        public LoopTodo(int id)
        {
            this.Id = id;
        }
        public int Id { get; }
    }
}
