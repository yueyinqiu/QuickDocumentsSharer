﻿using Entities.Helpers;

namespace DataHelpers.Memory.Standard
{
    public static class Factory
    {
        public static IDataHelper GetHelper()
        {
            return new Memory.Standard.MemoryHelper();
        }
    }
}
