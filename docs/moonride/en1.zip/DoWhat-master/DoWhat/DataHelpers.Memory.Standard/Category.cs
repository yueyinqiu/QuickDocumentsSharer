﻿using Entities.TodoRelated;

namespace DataHelpers.Memory.Standard
{
    internal class Category : ITodoCategory
    {
        public ITodoCategoryInfo Info { get; set; }

        public Category(int id)
        {
            this.Id = id;
        }
        public int Id { get; }

    }
}
