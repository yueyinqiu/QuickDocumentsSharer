﻿using Entities.TodoRelated;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataHelpers.Memory.Standard
{
    internal class MemoryHelper : Entities.Helpers.IDataHelper
    {
        private readonly List<CommonTodo> commonTodos = new List<CommonTodo>();
        private readonly List<LoopTodo> loopTodos = new List<LoopTodo>();

        public IEnumerable<ICommonTodo> AllCommonTodos => this.commonTodos;
        public IEnumerable<ILoopTodo> AllLoopTodos => this.loopTodos;

        public bool Change(ITodo todo, ICommonTodoInfo info)
        {
            foreach (var v in this.commonTodos)
            {
                if (v.Id == todo.Id)
                {
                    v.Info = info;
                    return true;
                }
            }
            return false;
        }
        public bool Change(ITodo todo, ILoopTodoInfo info)
        {
            foreach (var v in this.loopTodos)
            {
                if (v.Id == todo.Id)
                {
                    v.Info = info;
                    return true;
                }
            }
            return false;
        }

        private readonly Random rand = new Random();
        public ICommonTodo CreateNew(ICommonTodoInfo info)
        {
            int randNum = this.rand.Next();
            for (bool doNext = false; doNext;
                randNum = this.rand.Next(), doNext = false)
            {
                foreach (var v in this.commonTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }
                if (doNext)
                {
                    continue;
                }
                foreach (var v in this.loopTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }
                if (doNext)
                {
                    continue;
                }
            }
            var todoToSave = new CommonTodo(randNum) {
                Info = info
            };
            this.commonTodos.Add(todoToSave);
            return todoToSave;
        }
        public ILoopTodo CreateNew(ILoopTodoInfo info)
        {
            int randNum = this.rand.Next();
            for (bool doNext = false; doNext;
                randNum = this.rand.Next(), doNext = false)
            {
                foreach (var v in this.commonTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }
                if (doNext)
                {
                    continue;
                }
                foreach (var v in this.loopTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }
                if (doNext)
                {
                    continue;
                }
            }
            var todoToSave = new LoopTodo(randNum) {
                Info = info
            };
            this.loopTodos.Add(todoToSave);
            return todoToSave;
        }
        private readonly List<Category> categories = new List<Category>();
        public ITodoCategory CreateNew(ITodoCategoryInfo info)
        {
            int randNum = this.rand.Next();
            for (bool doNext = false; doNext;
                randNum = this.rand.Next(), doNext = false)
            {
                foreach (var v in this.commonTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }
                if (doNext)
                {
                    continue;
                }
                foreach (var v in this.loopTodos)
                {
                    if (v.Id == randNum)
                    {
                        doNext = true;
                        break;
                    }
                }

                if (doNext)
                {
                    continue;
                }
            }
            var cat = new Category(randNum) {
                Info = info
            };
            this.categories.Add(cat);
            return cat;
        }
        public ITodoCategory GetCategory(int categoryId)
        {
            var q = (from cat in this.categories
                     where cat.Id == categoryId
                     select cat).ToArray();
            if (q.Length == 0)
            {
                return null;
            }
            if (q.Length == 1)
            {
                return q[0];
            }
            throw new Exception("储存错误。");
        }

        public void Dispose() { }
        public ICommonTodo GetCommonTodo(ITodo todo)
        {
            var q = (from tod in this.commonTodos
                     where tod.Id == todo.Id
                     select tod).ToArray();
            if (q.Length == 0)
            {
                return null;
            }
            if (q.Length == 1)
            {
                return q[0];
            }
            throw new Exception("储存错误。");
        }
        public ILoopTodo GetLoopTodo(ITodo todo)
        {
            var q = (from tod in this.loopTodos
                     where tod.Id == todo.Id
                     select tod).ToArray();
            if (q.Length == 0)
            {
                return null;
            }
            if (q.Length == 1)
            {
                return q[0];
            }
            throw new Exception("储存错误。");
        }

        private IEnumerable<ITodoInSchedule> arrangement;
        public IEnumerable<ITodoInSchedule> GetSavedArrangement()
        {
            return this.arrangement;
        }
        public bool Remove(ITodo todo)
        {
            for (int i = 0; i < this.commonTodos.Count; i++)
            {
                if (this.commonTodos[i].Id == todo.Id)
                {
                    this.commonTodos.RemoveAt(i);
                    return true;
                }
            }
            for (int i = 0; i < this.loopTodos.Count; i++)
            {
                if (this.loopTodos[i].Id == todo.Id)
                {
                    this.loopTodos.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }
        public bool Remove(ITodoCategory category) => throw new NotImplementedException();
        public void SaveArrangement(IEnumerable<ITodoInSchedule> arrangement)
        {
            this.arrangement = arrangement;
        }

    }
}
