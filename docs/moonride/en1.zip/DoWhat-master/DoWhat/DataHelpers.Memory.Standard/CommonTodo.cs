﻿using Entities.TodoRelated;

namespace DataHelpers.Memory.Standard
{
    internal class CommonTodo : ICommonTodo
    {
        public ICommonTodoInfo Info { get; set; }

        public CommonTodo(int id)
        {
            this.Id = id;
        }
        public int Id { get; }
    }
}
