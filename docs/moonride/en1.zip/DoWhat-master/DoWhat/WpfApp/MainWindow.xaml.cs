﻿using Entities.Helpers;
using Entities.TodoRelated;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly BindingList<CTodoInfo> inputs = new BindingList<CTodoInfo>();
        private readonly IScheduleHelper scheduleHelper = ScheduleHelpers.Factory.GetScheduleHelper();
        public MainWindow()
        {
            this.InitializeComponent();
            this.gridIn.ItemsSource = this.inputs;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            this.hintBox.Text = "加载中……";
            try
            {
                IEnumerable<Result> result = await Task.Run(() =>
                {
                    IDataHelper data = DataHelpers.Memory.Standard.Factory.GetHelper();
                    this.scheduleHelper.SetData(data);

                    Dictionary<string, ITodoCategory> cats = new Dictionary<string, ITodoCategory>();
                    foreach (var v in this.inputs)
                    {
                        if (!cats.TryGetValue(v.Category, out ITodoCategory cat))
                        {
                            cat = data.CreateNew(new CategoryInfo() { Title = v.Category });
                            cats.Add(v.Category, cat);
                        }
                        data.CreateNew(v.ToCommonTodoInfo(cat.Id));
                    }

                    var sch = this.scheduleHelper.ProduceSchedules();
                    return result = from sc in sch
                                    select new Result() {
                                        StartTime = sc.StartTime,
                                        EndTime = sc.EndTime,
                                        Category = data.GetCategory(data.GetCommonTodo(sc.Todo).Info.CategoryId).Info.Title,
                                        Title = data.GetCommonTodo(sc.Todo).Info.Title
                                    };
                });
                this.gridOut.ItemsSource = result;
                this.hintBox.Text = "";
            }
            catch
            {
                this.hintBox.Text = "您的要求不符合人类时间认知，请修改";
            }
        }
    }
}
