﻿using System;

namespace WpfApp
{
    internal class Result
    {
        public string Title { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string Category { get; set; }
    }
}
