﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp
{
    internal class CategoryInfo : Entities.TodoRelated.ITodoCategoryInfo
    {
        public string Title { get; set; }
    }
}
