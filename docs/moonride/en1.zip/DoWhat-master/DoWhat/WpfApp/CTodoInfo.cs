﻿using Entities.TodoRelated;
using System;

namespace WpfApp
{
    public class CTodoInfo
    {
        public class CommonTodoInfo : ICommonTodoInfo
        {
            public int CategoryId { get; set; }

            public string Title { get; set; }

            public DateTime EarliestStartTime { get; set; }

            public DateTime Deadline { get; set; }

            public TimeSpan Consumption { get; set; }

            public int Importance { get; set; }
        }

        public string Category { get; set; } = "默认类型";

        public string Title { get; set; } = "默认标题";

        public DateTime EarliestStartTime { get; set; } = DateTime.Now;

        public DateTime Deadline { get; set; } = DateTime.Now.AddDays(1);

        public TimeSpan Consumption { get; set; } = TimeSpan.FromMinutes(10);

        public int Importance { get; set; } = 80;

        public ICommonTodoInfo ToCommonTodoInfo(int categoryId)
        {
            return new CommonTodoInfo() {
                CategoryId = categoryId,
                Consumption = this.Consumption,
                Deadline = this.Deadline,
                EarliestStartTime = this.EarliestStartTime,
                Importance = this.Importance,
                Title = this.Title
            };

        }
    }
}
